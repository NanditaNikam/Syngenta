import { Controller, Get, UseGuards, UseInterceptors } from '@nestjs/common';
import { AuthGuard } from './AuthGuard/auth.guard';
import { LoggingInterceptor } from './Interceptors/logging.interceptor';

@Controller('example')
@UseGuards(AuthGuard)
@UseInterceptors(LoggingInterceptor)
export class AppController {
  @Get()
  exampleRoute() {
    return 'Hello, World!';
  }
}

