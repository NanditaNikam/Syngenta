// middleware sits in between client request and router handlers
// when browser makes https requests to any the route inseide our application, before it can hit the controller
// and start executing the code, if we want to make any checks and balances then  we use middlewares

// middleware to check whether there is an api token in our header or not

import {
  BadRequestException,
  Injectable,
  NestMiddleware,
} from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';

@Injectable()
export class ApiTokenCheckMiddleware implements NestMiddleware {
  use(req: Request, res: Response, next: NextFunction) {
    console.log(req.headers)
    // console.log(req.headers);
    if (req.headers['api-token'] != 'my-token') {
      throw new BadRequestException('token does not match');
    }
    next(); // calling next fun here
  }
}
