import {
  Module,
  NestModule,
  MiddlewareConsumer,
  RequestMethod,
} from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ApiTokenCheckMiddleware } from './middleware/api-token-check-middleware';
import path from 'path';

@Module({
  imports: [],
  controllers: [AppController],
  providers: [AppService],
})
// export class AppModule {}
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    // consumer.apply(ApiTokenCheckMiddleware).forRoutes('posts');
    consumer.apply(ApiTokenCheckMiddleware).forRoutes({path: '*',method: RequestMethod.ALL});
  }
}
