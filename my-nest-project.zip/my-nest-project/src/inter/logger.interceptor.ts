//post processing of response before sending to client, basically interceptor intercepts request before handled to server
//  and intercepts response before sending back to client

// import {
//   ExecutionContext,
//   Injectable,
//   NestInterceptor,
//   CallHandler,
// } from '@nestjs/common';
// // import { Injectable, NestInterceptor, ExecutionContext, CallHandler } from "@nestjs/common/decorators";
// import { Observable } from 'rxjs';
// import { tap, catchError } from 'rxjs/operators';

// @Injectable()
// export class LoggerInterceptor implements NestInterceptor {
//   intercept(
//     context: ExecutionContext,
//     next: CallHandler<any>,
//   ): Observable<any> | Promise<Observable<any>> {
//     throw new Error('method not implemented');
//   }
// }

import {
  ExecutionContext,
  Injectable,
  NestInterceptor,
  CallHandler,
} from '@nestjs/common';

import { Observable } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';

@Injectable()
export class LoggerInterceptor implements NestInterceptor {
  intercept(
    context: ExecutionContext,
    next: CallHandler<any>,
  ): Observable<any> | Promise<Observable<any>> {
    const userAgent = context.switchToHttp().getRequest().headers['user-agent']; // we are capturing the user agent string,
    //  from browser or postman and calculating the execution time of the request being raised
    // this executes before request or after u send response, once we receive response we display the current time minus 
    // time when request is arrived

    const now = Date.now();
    return next.handle().pipe(
      tap((data) => {
        console.log(`After...${Date.now() - now}ms`, data, userAgent);
      }),
      catchError((err) => {
        console.log('err caught in interceptor', err);
        throw err;
      }),
    );
  }
}
