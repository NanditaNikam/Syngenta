import { Injectable } from '@nestjs/common';

@Injectable()
export class SingletonService {
  // eslint-disable-next-line @typescript-eslint/no-inferrable-types
  private counter: number = 0;

  public incrementCounter(): void {
    this.counter++;
  }

  public getCounterValue(): number {
    return this.counter;
  }
}
