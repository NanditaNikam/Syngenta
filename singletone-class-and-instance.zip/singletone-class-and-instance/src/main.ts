import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { OtherService } from './other.service';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  const otherService = app.get(OtherService);
  otherService.someMethod();

  await app.listen(3000);
}
bootstrap();
