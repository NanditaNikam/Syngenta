import { Injectable } from '@nestjs/common';
import { SingletonService } from './singleton.services';

@Injectable()
export class OtherService {
  constructor(private readonly singletonService: SingletonService) {}

  public someMethod(): void {
    this.singletonService.incrementCounter();
  }
}
