import { Controller, Get } from '@nestjs/common';
import { OtherService } from './other.service';

@Controller()
export class AppController {
  constructor(private readonly otherService: OtherService) {}

  @Get()
  getRoot(): string {
    return 'Hello, Nest.js!';
  }

  @Get('increment')
  incrementCounter(): string {
    this.otherService.someMethod();
    return 'Counter incremented!';
  }
}
