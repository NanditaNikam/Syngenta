/* eslint-disable prettier/prettier */
export const CARS = [
    {
    id : '1605085531457',
    brand: 'BMW',
    color: 'gold',
    model: 'BMW X5',
    },
];