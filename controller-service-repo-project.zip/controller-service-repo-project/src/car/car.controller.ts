/* eslint-disable prettier/prettier */
// controllers are responsible for controlling the request and response
import { Controller,Get } from '@nestjs/common';
import { CarService } from './car.service';

@Controller('car')
export class CarController {
//  service layer communicates between controller and repository layer

// repository layer is responsible for interacting with database
  constructor(private carService: CarService){}

// end point methods for car controller
@Get()
async getCars(){
   return this.carService.getCars();
} 

}
